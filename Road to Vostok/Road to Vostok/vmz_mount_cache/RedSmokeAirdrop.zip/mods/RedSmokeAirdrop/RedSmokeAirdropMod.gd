extends Node

const DEBUG_PREFIX = "[RedSmokeAirdrop] "
const META_HOOKED = "rsam_hooked"
const META_TRIGGERED = "rsam_triggered"

var smoke_scene = preload("res://mods/RedSmokeAirdrop/Assets/Airdrop/AirdropRedSmoke_2.tscn")
var smoke_instance: Node3D
var smoke_holder: Node3D

var active_airdrop_ref: WeakRef = null
var active_airdrop_id: int = -1

func _ready():
    await get_tree().process_frame
    
    print(DEBUG_PREFIX + "Init")
    
    # Monitor world scene change
    get_tree().scene_changed.connect(_on_scene_changed)
    
    # Start monitoring nodes
    get_tree().node_added.connect(_on_node_added)
        
func _on_scene_changed():
    var path = Loader.scenePath
    if path.is_empty():
        return
    
    var scene_name = path.get_basename().get_file()
    print(DEBUG_PREFIX + "World scene changed to %s, resetting state" % scene_name)

    # Reset tracking
    active_airdrop_ref = null
    active_airdrop_id = -1
    
    # Create a holder for smoke
    if not is_instance_valid(smoke_holder):
        smoke_holder = Node3D.new()
        smoke_holder.name = "RedSmokeHolder"
        get_tree().root.add_child(smoke_holder)
        smoke_holder.position = Vector3(0, 1000, 0)
        print(DEBUG_PREFIX + "Smoke holder created")
    
    # Pre-instantiate smoke
    if not is_instance_valid(smoke_instance):
        smoke_instance = smoke_scene.instantiate()
        smoke_instance.hide()
        print(DEBUG_PREFIX + "Smoke instance created")

    if (smoke_instance.get_parent()):
        smoke_instance.reparent(smoke_holder)
    else:
        smoke_holder.add_child(smoke_instance)
        
func _on_node_added(node: Node):
    if node.name == "Airdrop":
        hook_airdrop(node)
    
func hook_airdrop(airdrop_node: Node):
    if not is_instance_valid(airdrop_node):
        return
        
    var id = airdrop_node.get_instance_id()
    
    if airdrop_node.has_meta(META_HOOKED):
        print(DEBUG_PREFIX + "Airdrop %s (id: %s) is already hooked, skipping" % [airdrop_node.name, id])
        return

    airdrop_node.set_meta(META_HOOKED, true)

    var collided_cb = _on_mod_airdrop_collided.bind(airdrop_node)
    var exiting_cb = _on_mod_airdrop_exiting.bind(airdrop_node)

    if not airdrop_node.body_entered.is_connected(collided_cb):
        airdrop_node.body_entered.connect(collided_cb)
        
    if not airdrop_node.tree_exiting.is_connected(exiting_cb):
        airdrop_node.tree_exiting.connect(exiting_cb)
    
    print(DEBUG_PREFIX + "Hooked Airdrop %s (id: %s)" % [airdrop_node.name, id])
    
func _on_mod_airdrop_exiting(airdrop_node: Node3D):
    if not is_instance_valid(airdrop_node):
        return
        
    if not airdrop_node.is_queued_for_deletion():
        return
        
    var id = airdrop_node.get_instance_id()

    if active_airdrop_id == id:
        print(DEBUG_PREFIX + "Active Airdrop %s (id: %s) deleted, detaching smoke" % [airdrop_node.name, id])
        hide_smoke()

        active_airdrop_ref = null
        active_airdrop_id = -1
        
func _on_mod_airdrop_collided(body: Node, airdrop_node: Node3D):
    if not is_instance_valid(airdrop_node):
        return
        
    var id = airdrop_node.get_instance_id()
    
    # Safety check in case it's already removed or marked as triggered
    if airdrop_node.has_meta(META_TRIGGERED):
        return

    airdrop_node.set_meta(META_TRIGGERED, true) # Mark as triggered (ignore sequence bounces)
    
    print(DEBUG_PREFIX + "Airdrop %s (id: %s) has collided with %s" % [airdrop_node.name, id, body.name])
    spawn_red_smoke(airdrop_node)
    
func spawn_red_smoke(target: Node3D):
    if not is_instance_valid(target):
        return

    var id = target.get_instance_id()

    if active_airdrop_id == id:
        print(DEBUG_PREFIX + "Smoke is already attached to target %s (id: %s), skipping" % [target.name, id])
        return # already attached

    # Transfer ownership
    active_airdrop_ref = weakref(target)
    active_airdrop_id = id

    smoke_instance.reparent(target)
    smoke_instance.position = Vector3(0, 2.2, 0)
    smoke_instance.rotation = Vector3.ZERO
    smoke_instance.show()

    print(DEBUG_PREFIX + "Smoke attached to target %s (id: %s) " % [target.name, id])
    
func hide_smoke() -> void:
    if not is_instance_valid(smoke_instance):
        return
        
    if smoke_instance.get_parent():
         if is_instance_valid(smoke_holder) and smoke_instance.get_parent() != smoke_holder:
            smoke_instance.reparent(smoke_holder)
    else:
        get_tree().root.add_child(smoke_instance)
        
    smoke_instance.position = Vector3(0, 1000, 0)
    smoke_instance.hide()
    
func get_active_airdrop() -> Node3D:
    if active_airdrop_ref == null:
        return null

    var node = active_airdrop_ref.get_ref()
    
    if node == null:
        # Recover if freed without signal
        print(DEBUG_PREFIX + "Active airdrop vanished unexpectedly, recovering")

        active_airdrop_ref = null
        active_airdrop_id = -1

        if is_instance_valid(smoke_instance):
            hide_smoke()

        return null

    return node
