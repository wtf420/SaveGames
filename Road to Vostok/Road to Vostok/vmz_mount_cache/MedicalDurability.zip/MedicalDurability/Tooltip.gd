extends "res://Scripts/Tooltip.gd"

func Update(item: Item):
    super.Update(item)

    if item == null or item.slotData == null or item.slotData.itemData == null:
        return

    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null:
        return
    if !med_mod.is_medical_item(item.slotData.itemData):
        return

    med_mod.prepare_slot_data(item.slotData)
    var max_uses = int(med_mod.get_max_uses(item.slotData.itemData))
    if max_uses <= 1:
        return

    var uses_left = int(med_mod.get_uses_left(item.slotData))
    condition.show()

    if condition.get_child_count() == 0:
        return

    var value_label = condition.get_child(0)
    if value_label is Label:
        value_label.text = "%d/%d" % [uses_left, max_uses]

        var uses_ratio = float(uses_left) / float(max_uses)
        if uses_left <= 1 or uses_ratio <= 0.25:
            value_label.modulate = Color.RED
        elif uses_ratio <= 0.5:
            value_label.modulate = Color.YELLOW
        else:
            value_label.modulate = Color.GREEN

    # super.Update() computed panel size before we re-enabled Condition for medical items.
    # Recompute to avoid clipping tooltip borders/content.
    panel.size = Vector2(256, 0)
    interface.tooltipOffset = panel.size.y / 2.0
