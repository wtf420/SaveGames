extends "res://Scripts/Interface.gd"

const MD_DEBUG := false

func _md_dbg(message: String) -> void:
    if MD_DEBUG:
        print("[MedicalDurability][DBG] " + message)

func _md_prepare_slot(slotData: SlotData, targetGrid = null) -> void:
    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null or slotData == null or slotData.itemData == null:
        return

    med_mod.prepare_slot_data(slotData)

    # Trader supply should always be sold as full durability/uses.
    if targetGrid != null and targetGrid == supplyGrid and med_mod.is_medical_item(slotData.itemData):
        var max_uses = int(med_mod.get_max_uses(slotData.itemData))
        med_mod.set_uses_left(slotData, max_uses)

func _md_apply_counter_style(item_ref: Item) -> void:
    if item_ref == null or item_ref.slotData == null or item_ref.slotData.itemData == null:
        return

    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null:
        return
    if !med_mod.is_medical_item(item_ref.slotData.itemData):
        return

    # Keep trader stock full even if slot data got refreshed by other systems.
    if supplyGrid and item_ref.get_parent() == supplyGrid:
        var supply_max_uses = int(med_mod.get_max_uses(item_ref.slotData.itemData))
        med_mod.set_uses_left(item_ref.slotData, supply_max_uses)

    med_mod.prepare_slot_data(item_ref.slotData)
    var uses_left = int(med_mod.get_uses_left(item_ref.slotData))
    var max_uses = int(med_mod.get_max_uses(item_ref.slotData.itemData))
    if max_uses <= 1:
        return

    item_ref.condition.hide()
    item_ref.amount.anchor_left = 1.0
    item_ref.amount.anchor_top = 0.0
    item_ref.amount.anchor_right = 1.0
    item_ref.amount.anchor_bottom = 0.0
    item_ref.amount.offset_left = -24.0
    item_ref.amount.offset_top = 0.0
    item_ref.amount.offset_right = 0.0
    item_ref.amount.offset_bottom = 17.0
    item_ref.amount.custom_minimum_size = Vector2(24, 17)
    item_ref.amount.add_theme_font_size_override("font_size", 14)
    item_ref.amount.horizontal_alignment = 2
    item_ref.amount.vertical_alignment = 0
    item_ref.amount.text = str(uses_left)

    if uses_left <= 1:
        item_ref.amount.modulate = Color.RED
    elif uses_left <= int(ceil(float(max_uses) / 2.0)):
        item_ref.amount.modulate = Color.YELLOW
    else:
        item_ref.amount.modulate = Color.GREEN

    item_ref.amount.show()

func _md_restyle_visible_items() -> void:
    var grids = [inventoryGrid, containerGrid, catalogGrid, supplyGrid]
    for grid in grids:
        if grid and grid.is_visible_in_tree():
            for child in grid.get_children():
                if child is Item:
                    _md_apply_counter_style(child)

    if equipment and equipment.is_visible_in_tree():
        for equipment_slot in equipment.get_children():
            if equipment_slot is Slot and equipment_slot.get_child_count() != 0:
                var equipped_item = equipment_slot.get_child(0)
                if equipped_item is Item:
                    _md_apply_counter_style(equipped_item)

func _md_should_handle_use_locally(slot_data: SlotData) -> bool:
    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null or slot_data == null or slot_data.itemData == null:
        return false
    if !med_mod.is_medical_item(slot_data.itemData):
        return false

    med_mod.prepare_slot_data(slot_data)
    # Let the last use go through vanilla/super behavior for best compatibility.
    return int(med_mod.get_uses_left(slot_data)) > 1

func _md_find_item_by_slot(targetGrid, slotData: SlotData) -> Item:
    if targetGrid == null or slotData == null:
        return null

    for child in targetGrid.get_children():
        if child is Item and child.slotData == slotData:
            return child

    return null

func _md_restore_multi_use_after_super(slotData: SlotData, slot_snapshot: SlotData, targetGrid, uses_left: int) -> void:
    if targetGrid == null:
        _md_dbg("restore skipped: targetGrid=null")
        return

    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null:
        _md_dbg("restore skipped: med_mod=null")
        return

    var existing_item = _md_find_item_by_slot(targetGrid, slotData)
    if existing_item:
        med_mod.set_uses_left(existing_item.slotData, uses_left)
        med_mod.refresh_item_ui(self, existing_item)
        _md_dbg("restore existing item uses_left=%d" % uses_left)
        return

    var slot_to_restore: SlotData = slotData
    if slot_to_restore == null or slot_to_restore.itemData == null:
        slot_to_restore = slot_snapshot
    if slot_to_restore == null or slot_to_restore.itemData == null:
        _md_dbg("restore failed: no slot data")
        return

    med_mod.set_uses_left(slot_to_restore, uses_left)
    var stacked: bool = bool(AutoStack(slot_to_restore, targetGrid))
    if !stacked:
        Create(slot_to_restore, targetGrid, true)
    _md_dbg("restore new item uses_left=%d stacked=%s" % [uses_left, str(stacked)])

func _physics_process(delta):
    super._physics_process(delta)
    if Engine.get_physics_frames() % 5 == 0:
        _md_restyle_visible_items()

func LoadGridItem(slotData, targetGrid, gridPosition):
    _md_prepare_slot(slotData, targetGrid)
    super.LoadGridItem(slotData, targetGrid, gridPosition)
    _md_restyle_visible_items()

func LoadSlotItem(slotData, slotName):
    _md_prepare_slot(slotData)
    super.LoadSlotItem(slotData, slotName)
    _md_restyle_visible_items()

func Create(slotData, targetGrid, useDrop):
    _md_prepare_slot(slotData, targetGrid)
    var created = super.Create(slotData, targetGrid, useDrop)
    _md_restyle_visible_items()
    return created

func Use(targetItem, targetGrid):
    if targetItem == null or targetItem.slotData == null:
        return

    _md_prepare_slot(targetItem.slotData)
    var slotData = targetItem.slotData
    var med_mod = Engine.get_meta("MedicalDurability", null)
    var should_restore_multi_use: bool = (
        med_mod != null
        and targetGrid != null
        and _md_should_handle_use_locally(slotData)
    )
    var uses_before_super: int = 0
    var slot_snapshot: SlotData = null
    var consumedItem = slotData.itemData
    var is_medical_use: bool = med_mod != null and consumedItem != null and med_mod.is_medical_item(consumedItem)
    var used_items_backup = []

    if is_medical_use:
        var uses_now: int = int(med_mod.get_uses_left(slotData))
        _md_dbg("Use gate item=%s should_restore=%s uses_now=%d targetGrid=%s" % [
            str(consumedItem.file), str(should_restore_multi_use), uses_now, str(targetGrid != null)
        ])

    if should_restore_multi_use and consumedItem != null:
        uses_before_super = int(med_mod.get_uses_left(slotData))
        _md_dbg("Use start item=%s uses_before=%d" % [str(consumedItem.file), uses_before_super])
        var slot_snapshot_raw: Variant = slotData.duplicate(true)
        if slot_snapshot_raw is SlotData:
            slot_snapshot = slot_snapshot_raw as SlotData
        used_items_backup = consumedItem.used.duplicate(true)
        # Avoid spawning "used" leftovers before the final medical use.
        consumedItem.used.clear()

    await super(targetItem, targetGrid)

    if should_restore_multi_use and consumedItem != null:
        consumedItem.used = used_items_backup

        if !gameData.isDead:
            var uses_left_after_super: int = max(uses_before_super - 1, 0)
            _md_dbg("Use after super item=%s uses_after=%d" % [str(consumedItem.file), uses_left_after_super])
            if uses_left_after_super > 0:
                # Some mods/vanilla branches remove the slot deferred after Use().
                # Restore on the next frame so durability wins over deferred deletes.
                await get_tree().process_frame
                var exists_after_frame: bool = _md_find_item_by_slot(targetGrid, slotData) != null
                _md_dbg("Use post-frame exists=%s" % str(exists_after_frame))
                _md_restore_multi_use_after_super(slotData, slot_snapshot, targetGrid, uses_left_after_super)

    _md_restyle_visible_items()

func ContextSleep():
    if contextItem == null or contextGrid == null or contextItem.slotData == null:
        return

    _md_prepare_slot(contextItem.slotData)
    var slot_data = contextItem.slotData
    var source_grid = contextGrid
    var med_mod = Engine.get_meta("MedicalDurability", null)
    var should_restore_multi_use: bool = med_mod != null and _md_should_handle_use_locally(slot_data)
    var uses_before_super: int = 0
    var slot_snapshot: SlotData = null
    var sleep_item = slot_data.itemData
    var used_items_backup = []

    if should_restore_multi_use and sleep_item != null:
        uses_before_super = int(med_mod.get_uses_left(slot_data))
        _md_dbg("Sleep start item=%s uses_before=%d" % [str(sleep_item.file), uses_before_super])
        var sleep_snapshot_raw: Variant = slot_data.duplicate(true)
        if sleep_snapshot_raw is SlotData:
            slot_snapshot = sleep_snapshot_raw as SlotData
        used_items_backup = sleep_item.used.duplicate(true)
        sleep_item.used.clear()

    super()

    if should_restore_multi_use and sleep_item != null:
        sleep_item.used = used_items_backup

        var uses_left_after_super: int = max(uses_before_super - 1, 0)
        _md_dbg("Sleep after super item=%s uses_after=%d" % [str(sleep_item.file), uses_left_after_super])
        if uses_left_after_super > 0:
            _md_restore_multi_use_after_super(slot_data, slot_snapshot, source_grid, uses_left_after_super)

    _md_restyle_visible_items()
