extends "res://Scripts/Item.gd"

func _set_amount_layout_default() -> void:
    amount.anchor_left = 1.0
    amount.anchor_top = 1.0
    amount.anchor_right = 1.0
    amount.anchor_bottom = 1.0
    amount.offset_left = -5.0
    amount.offset_top = -17.0
    amount.offset_right = 0.0
    amount.offset_bottom = 0.0
    amount.custom_minimum_size = Vector2.ZERO
    amount.add_theme_font_size_override("font_size", 12)
    amount.horizontal_alignment = 2
    amount.vertical_alignment = 2

func _set_amount_layout_medical_counter() -> void:
    amount.anchor_left = 1.0
    amount.anchor_top = 0.0
    amount.anchor_right = 1.0
    amount.anchor_bottom = 0.0
    amount.offset_left = -24.0
    amount.offset_top = 0.0
    amount.offset_right = 0.0
    amount.offset_bottom = 17.0
    amount.custom_minimum_size = Vector2(24, 17)
    amount.add_theme_font_size_override("font_size", 14)
    amount.horizontal_alignment = 2
    amount.vertical_alignment = 0

func UpdateDetails():
    super.UpdateDetails()
    _set_amount_layout_default()

    if slotData == null or slotData.itemData == null:
        return

    var med_mod = Engine.get_meta("MedicalDurability", null)
    if med_mod == null:
        return
    if !med_mod.is_medical_item(slotData.itemData):
        return

    med_mod.prepare_slot_data(slotData)
    var max_uses = int(med_mod.get_max_uses(slotData.itemData))
    if max_uses <= 1:
        return

    var uses_left = int(med_mod.get_uses_left(slotData))
    condition.hide()
    _set_amount_layout_medical_counter()
    amount.text = str(uses_left)

    if uses_left <= 1:
        amount.modulate = Color.RED
    elif uses_left <= int(ceil(float(max_uses) / 2.0)):
        amount.modulate = Color.YELLOW
    else:
        amount.modulate = Color.GREEN

    amount.show()
