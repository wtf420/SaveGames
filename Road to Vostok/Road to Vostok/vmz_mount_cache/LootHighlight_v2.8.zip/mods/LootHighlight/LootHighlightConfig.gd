extends Node

var lh_settings = preload("res://mods/LootHighlight/LH_Settings.tres")
var McmHelpers = load("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres")
var MCMNotInstalledUI = preload("res://ModConfigurationMenu/UI/mcm_not_installed.tscn")

const MOD_ID = "LootHighlight"
const FILE_PATH = "user://MCM/LootHighlight"

func _ready():
        var _config = ConfigFile.new()

        _config.set_value("Category", "Visual", {"menu_pos" = 1})
        _config.set_value("Color", "lh_color", {
                "name" = "Highlight Color",
                "tooltip" = "Color of the loot outline glow",
                "default" = Color(1.0, 1.0, 1.0, 1.0),
                "value" = Color(1.0, 1.0, 1.0, 1.0),
                "category" = "Visual",
                "menu_pos" = 1
        })
        _config.set_value("Float", "lh_thickness", {
                "name" = "Outline Thickness",
                "tooltip" = "Width of the highlight outline",
                "default" = 0.002,
                "value" = 0.002,
                "minRange" = 0.001,
                "maxRange" = 0.02,
                "category" = "Visual",
                "menu_pos" = 2
        })
        _config.set_value("Float", "lh_brightness", {
                "name" = "Outline Intensity",
                "tooltip" = "Brightness of the highlight outline",
                "default" = 0.2,
                "value" = 0.2,
                "minRange" = 0.05,
                "maxRange" = 3.0,
                "category" = "Visual",
                "menu_pos" = 3
        })
        _config.set_value("Float", "lh_distance", {
                "name" = "Max Distance",
                "tooltip" = "Maximum distance (m) to show loot highlights",
                "default" = 20.0,
                "value" = 20.0,
                "minRange" = 1.0,
                "maxRange" = 100.0,
                "category" = "Visual",
                "menu_pos" = 4
        })
        _config.set_value("Category", "Behavior", {"menu_pos" = 2})
        _config.set_value("Bool", "lh_enabled", {
                "name" = "Enabled",
                "tooltip" = "Toggle loot highlighting on/off",
                "default" = true,
                "value" = true,
                "category" = "Behavior",
                "menu_pos" = 1
        })
        _config.set_value("Bool", "lh_shelter_auto", {
                "name" = "Shelter Auto-Pause",
                "tooltip" = "Automatically hide highlights inside shelters",
                "default" = true,
                "value" = true,
                "category" = "Behavior",
                "menu_pos" = 2
        })
        _config.set_value("Bool", "lh_enemy_weapons", {
                "name" = "Enemy Gear",
                "tooltip" = "Highlight gear on dead enemy bodies",
                "default" = false,
                "value" = false,
                "category" = "Behavior",
                "menu_pos" = 3
        })
        _config.set_value("String", "lh_custom_shelters", {
                "name" = "Custom Locations",
                "tooltip" = "Comma-separated scene keywords treated as shelters (e.g. apartment,hideout). Changes take effect on scene change.",
                "default" = "apartment",
                "value" = "apartment",
                "category" = "Behavior",
                "menu_pos" = 4
        })
        _config.set_value("Keycode", "lh_toggle_key", {
                "name" = "Menu Toggle Key",
                "tooltip" = "Key to open/close the Loot Highlight settings menu.",
                "default" = 4194338,
                "default_type" = "Key",
                "value" = 4194338,
                "type" = "Key",
                "category" = "Behavior",
                "menu_pos" = 5
        })

        if McmHelpers:
                if !FileAccess.file_exists(FILE_PATH + "/config.ini"):
                        DirAccess.open("user://").make_dir(FILE_PATH)
                        _config.save(FILE_PATH + "/config.ini")
                else:
                        McmHelpers.CheckConfigurationHasUpdated(MOD_ID, _config, FILE_PATH + "/config.ini")
                        _config.load(FILE_PATH + "/config.ini")
                        UpdateConfigProperties(_config)

                McmHelpers.RegisterConfiguration(
                        MOD_ID,
                        "Loot Highlight",
                        FILE_PATH,
                        "Thin bright edge on loose items — inverted-hull outline",
                        {
                                "config.ini" = UpdateConfigProperties
                        }
                )
        else:
                var _notInstalledUI = MCMNotInstalledUI.instantiate()
                _notInstalledUI.find_child("Link").pressed.connect(func():
                        OS.shell_open("https://modworkshop.net/mod/53713")
                )
                _notInstalledUI.find_child("Quit").pressed.connect(func():
                        Loader.Quit()
                )
                _notInstalledUI.find_child("Description").text = "Mod Configuration Menu must be installed to use " + MOD_ID + ". The button below will take you to the MCM ModWorkshop page."
                for _element in get_parent().get_children():
                        if _element.name == "Menu":
                                _element.find_child("Main").hide()
                                _element.add_child(_notInstalledUI)


func UpdateConfigProperties(_config: ConfigFile):
        lh_settings.color        = _read(_config, "Color", "lh_color",         Color(1, 1, 1, 1))
        lh_settings.grow         = _read(_config, "Float", "lh_thickness",      0.002)
        lh_settings.brightness   = _read(_config, "Float", "lh_brightness",     0.2)
        lh_settings.distance     = _read(_config, "Float", "lh_distance",       20.0)
        lh_settings.enabled      = _read(_config, "Bool",  "lh_enabled",        true)
        lh_settings.shelter_auto = _read(_config, "Bool",  "lh_shelter_auto",   true)
        lh_settings.enemy_weapons = _read(_config, "Bool", "lh_enemy_weapons",  false)
        lh_settings.custom_shelters = _read(_config, "String", "lh_custom_shelters", "apartment")
        lh_settings.toggle_key   = _get_keycode(_config, "lh_toggle_key", 4194338)
        lh_settings.dirty = true  # Main.gd polls this flag in _process and applies


func _read(cfg: ConfigFile, section: String, key: String, fallback: Variant) -> Variant:
        if not cfg.has_section_key(section, key):
                return fallback
        var v = cfg.get_value(section, key)
        if v is Dictionary:
                return v.get("value", fallback)
        return v

func _get_keycode(cfg: ConfigFile, key: String, fallback: int) -> int:
        var v = cfg.get_value("Keycode", key, null)
        if v == null:
                return fallback
        if typeof(v) == TYPE_DICTIONARY and v.has("value"):
                return int(v["value"])
        return int(v)
