extends Node

# ═══════════════════════════════════════════════════════════════════
# CONFIGURATION DEFAULTS
# ═══════════════════════════════════════════════════════════════════

const DEFAULT_TOGGLE_KEY := KEY_F7
const MCM_CONFIG_PATH := "user://MCM/LootHighlight/config.ini"
const SCAN_KEY := KEY_TAB
const DEFAULT_COLOR := Color(1.0, 1.0, 1.0, 1.0)
const DEFAULT_GROW := 0.002
const DEFAULT_BRIGHTNESS := 0.2
const DEFAULT_DISTANCE := 20.0
const DEBUG_LOG := false
const SHELTER_SCENES := ["cabin", "attic", "tent", "bunker", "classroom"]
const SCAN_NODES_PER_FRAME := 15

# ═══════════════════════════════════════════════════════════════════
# RUNTIME CONFIG
# ═══════════════════════════════════════════════════════════════════

var lh_settings = preload("res://mods/LootHighlight/LH_Settings.tres")

var _current_color: Color = DEFAULT_COLOR
var _current_grow: float = DEFAULT_GROW
var _current_brightness: float = DEFAULT_BRIGHTNESS
var _current_distance: float = DEFAULT_DISTANCE
var _user_enabled: bool = true
var _shelter_auto: bool = true
var _in_shelter: bool = false
var _toggle_key: int = DEFAULT_TOGGLE_KEY
var _enemy_weapons: bool = true


# ═══════════════════════════════════════════════════════════════════
# INTERNALS
# ═══════════════════════════════════════════════════════════════════

var _shader: Shader
var _outline_mat: ShaderMaterial
var _highlighted: Dictionary = {}
var _rejected: Dictionary = {}
var _excluded_ancestors: Dictionary = {}  # cache: node oid -> bool
var _frame_counter: int = 0
var _last_scene_name: String = ""
var _scan_queue: Array[Node] = []
var _scan_active: bool = false
var _mcm_syncing: bool = false  # guard: skip MCM write-back when applying MCM changes
var _mcm_save_pending: bool = false  # debounce: coalesce rapid slider changes

# ═══════════════════════════════════════════════════════════════════
# GUI VARIABLES
# ═══════════════════════════════════════════════════════════════════

var _gui_canvas: CanvasLayer
var _gui_panel: PanelContainer
var _gui_blocker: Control
var _gui_visible: bool = false
var _saved_mouse_mode: int = Input.MOUSE_MODE_CAPTURED
var _color_btn: ColorPickerButton
var _thickness_slider: HSlider
var _brightness_slider: HSlider
var _thickness_val_label: Label
var _brightness_val_label: Label
var _distance_slider: HSlider
var _distance_val_label: Label
var _enable_check: CheckBox
var _shelter_check: CheckBox
var _enemy_weapons_check: CheckBox
var _scene_info_label: Label
var _keybind_btn: Button
var _listening_for_keybind: bool = false
var _custom_shelter_list: Array[String] = []
var _shelter_toggle_btn: Button
var _shelter_content: VBoxContainer
var _shelter_scroll: ScrollContainer
var _shelter_list_vbox: VBoxContainer
var _shelter_add_input: LineEdit


# ═══════════════════════════════════════════════════════════════════
# ACTIVE STATE = user enabled AND (not in shelter OR shelter auto off)
# ═══════════════════════════════════════════════════════════════════

func _is_active() -> bool:
        return _user_enabled and not (_in_shelter and _shelter_auto)

func _log(msg: String) -> void:
        if DEBUG_LOG:
                print(msg)

# ═══════════════════════════════════════════════════════════════════
# READY
# ═══════════════════════════════════════════════════════════════════

func _ready() -> void:
        _log("[LH] _ready START")
        process_mode = Node.PROCESS_MODE_ALWAYS
        _load_keybind()
        _shader = load("res://mods/LootHighlight/highlight_outline.gdshader")
        if _shader == null:
                print("[LH] ERROR: shader failed to load")
                return
        _outline_mat = ShaderMaterial.new()
        _outline_mat.shader = _shader
        _outline_mat.set_shader_parameter("grow", _current_grow)
        _outline_mat.set_shader_parameter("outline_color", _current_color)
        _outline_mat.set_shader_parameter("brightness", _current_brightness)

        # Initial scan after scene loads
        _check_scene_change()
        get_tree().create_timer(1.5).timeout.connect(_full_scan)

        # Catch items that enter the scene after the initial scan
        # (dropped items, late-spawned world loot, script-spawned items)
        get_tree().node_added.connect(_on_node_added)

        # Create CanvasLayer for GUI rendering
        _gui_canvas = CanvasLayer.new()
        _gui_canvas.layer = 120
        _gui_canvas.process_mode = Node.PROCESS_MODE_ALWAYS
        add_child(_gui_canvas)

        _build_gui()
        sync_settings()
        _log("[LH] _ready DONE")

# ═══════════════════════════════════════════════════════════════════
# GUI — built entirely in code, no .tscn needed
# ═══════════════════════════════════════════════════════════════════

func _build_gui() -> void:
        # ── Full-screen blocker: catches mouse clicks outside the panel ──
        _gui_blocker = Control.new()
        _gui_blocker.set_anchors_preset(Control.PRESET_FULL_RECT)
        _gui_blocker.mouse_filter = Control.MOUSE_FILTER_STOP
        _gui_blocker.visible = false
        _gui_blocker.process_mode = Node.PROCESS_MODE_ALWAYS
        _gui_canvas.add_child(_gui_blocker)

        # ── Panel ──
        _gui_panel = PanelContainer.new()
        _gui_panel.visible = false
        _gui_panel.custom_minimum_size = Vector2(280, 0)
        _gui_panel.mouse_filter = Control.MOUSE_FILTER_STOP
        _gui_panel.process_mode = Node.PROCESS_MODE_ALWAYS

        var style = StyleBoxFlat.new()
        style.bg_color = Color(0.1, 0.1, 0.1, 0.92)
        style.border_color = Color(0.35, 0.35, 0.35, 1.0)
        style.set_border_width_all(1)
        style.set_corner_radius_all(6)
        style.set_content_margin_all(10)
        _gui_panel.add_theme_stylebox_override("panel", style)

        var vbox = VBoxContainer.new()
        vbox.add_theme_constant_override("separation", 5)
        _gui_panel.add_child(vbox)

        # ── Title bar ──
        var title_bar = HBoxContainer.new()
        vbox.add_child(title_bar)

        var title_label = Label.new()
        title_label.text = "Loot Highlighter v2.8"
        title_label.add_theme_font_size_override("font_size", 15)
        title_label.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0, 1.0))
        title_bar.add_child(title_label)

        var title_spacer = Control.new()
        title_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        title_bar.add_child(title_spacer)

        var close_btn = Button.new()
        close_btn.text = "X"
        close_btn.custom_minimum_size = Vector2(28, 28)
        close_btn.pressed.connect(_close_gui)
        title_bar.add_child(close_btn)

        vbox.add_child(HSeparator.new())

        # ── Enable toggle ──
        _enable_check = CheckBox.new()
        _enable_check.text = "Enabled"
        _enable_check.button_pressed = _user_enabled
        _enable_check.toggled.connect(_on_enable_toggled)
        vbox.add_child(_enable_check)

        vbox.add_child(HSeparator.new())

        # ── Color ──
        var color_row = HBoxContainer.new()
        vbox.add_child(color_row)

        var color_label = Label.new()
        color_label.text = "Color"
        color_label.set_custom_minimum_size(Vector2(80, 0))
        color_row.add_child(color_label)

        var color_spacer = Control.new()
        color_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        color_row.add_child(color_spacer)

        _color_btn = ColorPickerButton.new()
        _color_btn.custom_minimum_size = Vector2(50, 28)
        _color_btn.color = _current_color
        _color_btn.color_changed.connect(_on_color_changed)
        _color_btn.get_popup().about_to_popup.connect(_reposition_color_picker)
        color_row.add_child(_color_btn)

        vbox.add_child(HSeparator.new())

        # ── Thickness slider ──
        _thickness_slider = HSlider.new()
        _thickness_slider.min_value = 0.001
        _thickness_slider.max_value = 0.02
        _thickness_slider.step = 0.001
        _thickness_slider.value = _current_grow
        _thickness_slider.custom_minimum_size = Vector2(0, 20)
        _thickness_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _thickness_slider.value_changed.connect(_on_thickness_changed)
        vbox.add_child(_thickness_slider)

        var thick_val_row = HBoxContainer.new()
        vbox.add_child(thick_val_row)

        var thick_name = Label.new()
        thick_name.text = "Thickness"
        thick_name.set_custom_minimum_size(Vector2(80, 0))
        thick_val_row.add_child(thick_name)

        var thick_spacer = Control.new()
        thick_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        thick_val_row.add_child(thick_spacer)

        _thickness_val_label = Label.new()
        _thickness_val_label.text = "%.3f" % _current_grow
        _thickness_val_label.set_custom_minimum_size(Vector2(45, 0))
        _thickness_val_label.set_alignment(HORIZONTAL_ALIGNMENT_RIGHT)
        thick_val_row.add_child(_thickness_val_label)

        # ── Intensity slider ──
        _brightness_slider = HSlider.new()
        _brightness_slider.min_value = 0.05
        _brightness_slider.max_value = 3.0
        _brightness_slider.step = 0.05
        _brightness_slider.value = _current_brightness
        _brightness_slider.custom_minimum_size = Vector2(0, 20)
        _brightness_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _brightness_slider.value_changed.connect(_on_brightness_changed)
        vbox.add_child(_brightness_slider)

        var bright_val_row = HBoxContainer.new()
        vbox.add_child(bright_val_row)

        var bright_name = Label.new()
        bright_name.text = "Intensity"
        bright_name.set_custom_minimum_size(Vector2(80, 0))
        bright_val_row.add_child(bright_name)

        var bright_spacer = Control.new()
        bright_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        bright_val_row.add_child(bright_spacer)

        _brightness_val_label = Label.new()
        _brightness_val_label.text = "%.2f" % _current_brightness
        _brightness_val_label.set_custom_minimum_size(Vector2(45, 0))
        _brightness_val_label.set_alignment(HORIZONTAL_ALIGNMENT_RIGHT)
        bright_val_row.add_child(_brightness_val_label)

        # ── Distance slider ──
        _distance_slider = HSlider.new()
        _distance_slider.min_value = 1.0
        _distance_slider.max_value = 100.0
        _distance_slider.step = 1.0
        _distance_slider.value = _current_distance
        _distance_slider.custom_minimum_size = Vector2(0, 20)
        _distance_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _distance_slider.value_changed.connect(_on_distance_changed)
        vbox.add_child(_distance_slider)

        var dist_val_row = HBoxContainer.new()
        vbox.add_child(dist_val_row)

        var dist_name = Label.new()
        dist_name.text = "Distance"
        dist_name.set_custom_minimum_size(Vector2(80, 0))
        dist_val_row.add_child(dist_name)

        var dist_spacer = Control.new()
        dist_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        dist_val_row.add_child(dist_spacer)

        _distance_val_label = Label.new()
        _distance_val_label.text = "%.0fm" % _current_distance
        _distance_val_label.set_custom_minimum_size(Vector2(45, 0))
        _distance_val_label.set_alignment(HORIZONTAL_ALIGNMENT_RIGHT)
        dist_val_row.add_child(_distance_val_label)

        vbox.add_child(HSeparator.new())

        # ── Shelter auto-pause toggle ──
        _shelter_check = CheckBox.new()
        _shelter_check.text = "Shelter Auto-Pause"
        _shelter_check.button_pressed = _shelter_auto
        _shelter_check.toggled.connect(_on_shelter_toggled)
        vbox.add_child(_shelter_check)

        # ── Collapsible Custom Locations section ──
        var shelter_toggle_row = HBoxContainer.new()
        vbox.add_child(shelter_toggle_row)

        _shelter_toggle_btn = Button.new()
        _shelter_toggle_btn.text = ">"
        _shelter_toggle_btn.custom_minimum_size = Vector2(24, 22)
        _shelter_toggle_btn.pressed.connect(_on_toggle_shelter_section)
        shelter_toggle_row.add_child(_shelter_toggle_btn)

        var shelter_toggle_label = Label.new()
        shelter_toggle_label.text = "Custom Locations"
        shelter_toggle_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7, 1.0))
        shelter_toggle_row.add_child(shelter_toggle_label)

        # Collapsible content container
        _shelter_content = VBoxContainer.new()
        _shelter_content.add_theme_constant_override("separation", 4)
        _shelter_content.visible = false  # collapsed by default
        vbox.add_child(_shelter_content)

        # ── Scrollable shelter list ──
        _shelter_scroll = ScrollContainer.new()
        _shelter_scroll.custom_minimum_size = Vector2(0, 120)
        _shelter_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
        _shelter_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _shelter_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
        _shelter_content.add_child(_shelter_scroll)

        _shelter_list_vbox = VBoxContainer.new()
        _shelter_list_vbox.add_theme_constant_override("separation", 2)
        _shelter_list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _shelter_scroll.add_child(_shelter_list_vbox)

        # ── Add shelter row: [+] [input field] ──
        var add_row = HBoxContainer.new()
        _shelter_content.add_child(add_row)

        var add_btn = Button.new()
        add_btn.text = "Add"
        add_btn.custom_minimum_size = Vector2(50, 24)
        add_btn.pressed.connect(_on_add_shelter)
        add_row.add_child(add_btn)

        _shelter_add_input = LineEdit.new()
        _shelter_add_input.placeholder_text = "shelter name"
        _shelter_add_input.tooltip_text = "Type a shelter keyword and press + or Enter"
        _shelter_add_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        _shelter_add_input.text_submitted.connect(_on_add_shelter)
        add_row.add_child(_shelter_add_input)

        # ── Enemy Weapons toggle ──
        _enemy_weapons_check = CheckBox.new()
        _enemy_weapons_check.text = "Enemy Gear | Press TAB after combat"
        _enemy_weapons_check.button_pressed = _enemy_weapons
        _enemy_weapons_check.toggled.connect(_on_enemy_weapons_toggled)
        vbox.add_child(_enemy_weapons_check)

        # ── Menu Key rebind ──
        var keybind_row = HBoxContainer.new()
        vbox.add_child(keybind_row)

        var keybind_label = Label.new()
        keybind_label.text = "Menu Key"
        keybind_label.set_custom_minimum_size(Vector2(80, 0))
        keybind_row.add_child(keybind_label)

        var keybind_spacer = Control.new()
        keybind_spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
        keybind_row.add_child(keybind_spacer)

        _keybind_btn = Button.new()
        _keybind_btn.text = OS.get_keycode_string(_toggle_key)
        _keybind_btn.custom_minimum_size = Vector2(80, 28)
        _keybind_btn.pressed.connect(_start_keybind_capture)
        keybind_row.add_child(_keybind_btn)

        # ── Scene info label ──
        _scene_info_label = Label.new()
        _scene_info_label.text = "Scene: --"
        _scene_info_label.add_theme_font_size_override("font_size", 10)
        _scene_info_label.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5, 1.0))
        vbox.add_child(_scene_info_label)

        _gui_canvas.add_child(_gui_panel)
        _gui_panel.reset_size()
        call_deferred("_reposition_gui")

func _reposition_gui() -> void:
        if _gui_panel == null:
                return
        var vp = get_viewport()
        if vp == null:
                return
        var vp_size = vp.get_visible_rect().size
        if _gui_blocker != null:
                _gui_blocker.size = vp_size
                _gui_blocker.position = Vector2.ZERO
        var panel_size: Vector2 = _gui_panel.size
        _gui_panel.position = Vector2(
                vp_size.x - panel_size.x - 20,
                20
        )

func _reposition_color_picker() -> void:
        if _color_btn == null or _gui_panel == null:
                return
        var popup = _color_btn.get_popup()
        if popup == null:
                return
        var btn_global = _color_btn.get_global_rect()
        var popup_width = popup.size.x
        var new_x = _gui_panel.position.x - popup_width - 10
        if new_x < 0:
                new_x = 0
        popup.position = Vector2(new_x, btn_global.position.y)

func _toggle_gui() -> void:
        _gui_visible = not _gui_visible
        if _gui_visible:
                _saved_mouse_mode = Input.mouse_mode
                Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
                get_tree().paused = true
                _gui_blocker.visible = true
                _gui_panel.visible = true
                _reposition_gui()
        else:
                _close_gui()

func _close_gui() -> void:
        _gui_visible = false
        _listening_for_keybind = false
        if _gui_panel != null:
                _gui_panel.visible = false
        if _gui_blocker != null:
                _gui_blocker.visible = false
        get_tree().paused = false
        Input.mouse_mode = _saved_mouse_mode
        if _keybind_btn:
                _keybind_btn.text = OS.get_keycode_string(_toggle_key)

# ═══════════════════════════════════════════════════════════════════
# GUI CALLBACKS — update shader params in real-time + sync to MCM
# ═══════════════════════════════════════════════════════════════════

func _on_color_changed(color: Color) -> void:
        _current_color = color
        lh_settings.color = color
        if _outline_mat != null:
                _outline_mat.set_shader_parameter("outline_color", color)
        _save_settings_to_mcm()

func _on_thickness_changed(value: float) -> void:
        _current_grow = value
        lh_settings.grow = value
        if _outline_mat != null:
                _outline_mat.set_shader_parameter("grow", value)
        if _thickness_val_label != null:
                _thickness_val_label.text = "%.3f" % value
        _save_settings_to_mcm()

func _on_brightness_changed(value: float) -> void:
        _current_brightness = value
        lh_settings.brightness = value
        if _outline_mat != null:
                _outline_mat.set_shader_parameter("brightness", value)
        if _brightness_val_label != null:
                _brightness_val_label.text = "%.2f" % value
        _save_settings_to_mcm()

func _on_distance_changed(value: float) -> void:
        _current_distance = value
        lh_settings.distance = value
        if _distance_val_label != null:
                _distance_val_label.text = "%.0fm" % value
        _save_settings_to_mcm()

func _on_enable_toggled(enabled: bool) -> void:
        _user_enabled = enabled
        lh_settings.enabled = enabled
        _log("[LH] Toggle -> " + ("ON" if enabled else "OFF"))
        if not _is_active():
                _safe_remove_all_outlines()
        elif _highlighted.is_empty():
                _full_scan(false)
        _save_settings_to_mcm()

func _on_shelter_toggled(enabled: bool) -> void:
        _shelter_auto = enabled
        lh_settings.shelter_auto = enabled
        _log("[LH] Shelter auto -> " + ("ON" if enabled else "OFF"))
        if not enabled and _in_shelter and _user_enabled:
                _full_scan(true)
        elif enabled and _in_shelter:
                _safe_remove_all_outlines()
        _save_settings_to_mcm()

func _on_enemy_weapons_toggled(enabled: bool) -> void:
        var changed: bool = (_enemy_weapons != enabled)
        _enemy_weapons = enabled
        lh_settings.enemy_weapons = enabled
        _log("[LH] Enemy weapons -> " + ("ON" if enabled else "OFF"))
        if changed and _is_active():
                _full_scan(true)
        _save_settings_to_mcm()

func _on_toggle_shelter_section() -> void:
        if _shelter_content == null:
                return
        _shelter_content.visible = not _shelter_content.visible
        if _shelter_toggle_btn != null:
                _shelter_toggle_btn.text = "v" if _shelter_content.visible else ">"
        # Force panel to recalculate size so it shrinks when collapsed
        if _gui_panel != null:
                _gui_panel.reset_size()
        if _shelter_content.visible:
                _refresh_shelter_list_gui()

func _on_add_shelter(_text: String = "") -> void:
        if _shelter_add_input == null:
                return
        var new_kw: String = _shelter_add_input.text.strip_edges().to_lower()
        if new_kw == "":
                return
        # Prevent duplicates
        for existing in _custom_shelter_list:
                if existing == new_kw:
                        _shelter_add_input.text = ""
                        return
        _custom_shelter_list.append(new_kw)
        _sync_shelters_to_settings()
        _shelter_add_input.text = ""
        _refresh_shelter_list_gui()

func _on_remove_shelter(kw: String) -> void:
        _custom_shelter_list.erase(kw)
        _sync_shelters_to_settings()
        _refresh_shelter_list_gui()

func _sync_shelters_to_settings() -> void:
        lh_settings.custom_shelters = ",".join(_custom_shelter_list)
        _save_settings_to_mcm()
        _recheck_shelter()

func _parse_custom_shelters() -> void:
        _custom_shelter_list.clear()
        for kw in lh_settings.custom_shelters.split(",", false):
                var trimmed: String = kw.strip_edges().to_lower()
                if trimmed != "":
                        _custom_shelter_list.append(trimmed)

func _refresh_shelter_list_gui() -> void:
        if _shelter_list_vbox == null:
                return
        # Clear existing list items
        for child in _shelter_list_vbox.get_children():
                child.queue_free()
        # Rebuild list
        for kw in _custom_shelter_list:
                var row = HBoxContainer.new()
                row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
                _shelter_list_vbox.add_child(row)

                var del_btn = Button.new()
                del_btn.text = "X"
                del_btn.custom_minimum_size = Vector2(24, 20)
                del_btn.pressed.connect(_on_remove_shelter.bind(kw))
                row.add_child(del_btn)

                var lbl = Label.new()
                lbl.text = kw
                lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85, 1.0))
                lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
                row.add_child(lbl)

                var spacer = Control.new()
                spacer.set_h_size_flags(Control.SIZE_EXPAND_FILL)
                row.add_child(spacer)

# ═══════════════════════════════════════════════════════════════════
# KEYBIND — load persisted key + in-game rebind + MCM write-back
# ═══════════════════════════════════════════════════════════════════

func _load_keybind() -> void:
        _toggle_key = lh_settings.toggle_key if lh_settings.toggle_key > 0 else DEFAULT_TOGGLE_KEY
        _log("[LH] Loaded keybind: " + OS.get_keycode_string(_toggle_key))

func _start_keybind_capture() -> void:
        _listening_for_keybind = true
        _keybind_btn.text = "Press a key..."
        _keybind_btn.release_focus()
        _log("[LH] Listening for keybind")

func _finish_keybind_capture(keycode: int) -> void:
        _listening_for_keybind = false
        _toggle_key = keycode
        lh_settings.toggle_key = keycode
        _keybind_btn.text = OS.get_keycode_string(keycode)
        _log("[LH] Keybind changed to: " + OS.get_keycode_string(keycode) + " (code=" + str(keycode) + ")")
        _save_settings_to_mcm()
        _keybind_btn.grab_focus()

# ═══════════════════════════════════════════════════════════════════
# MCM SYNC — write current runtime values back to MCM config.ini
# ═══════════════════════════════════════════════════════════════════

func _save_settings_to_mcm() -> void:
        if _mcm_syncing:
                return
        if _mcm_save_pending:
                return
        _mcm_save_pending = true
        get_tree().create_timer(0.5).timeout.connect(_do_mcm_save, CONNECT_ONE_SHOT)

func _do_mcm_save() -> void:
        _mcm_save_pending = false
        if not FileAccess.file_exists(MCM_CONFIG_PATH):
                _log("[LH] MCM config not found, skipping save")
                return
        var cfg = ConfigFile.new()
        if cfg.load(MCM_CONFIG_PATH) != OK:
                return

        # Update Color
        if cfg.has_section_key("Color", "lh_color"):
                var entry = cfg.get_value("Color", "lh_color")
                if entry is Dictionary:
                        entry["value"] = _current_color
                        cfg.set_value("Color", "lh_color", entry)

        # Update Float values
        if cfg.has_section_key("Float", "lh_thickness"):
                var entry = cfg.get_value("Float", "lh_thickness")
                if entry is Dictionary:
                        entry["value"] = _current_grow
                        cfg.set_value("Float", "lh_thickness", entry)

        if cfg.has_section_key("Float", "lh_brightness"):
                var entry = cfg.get_value("Float", "lh_brightness")
                if entry is Dictionary:
                        entry["value"] = _current_brightness
                        cfg.set_value("Float", "lh_brightness", entry)

        if cfg.has_section_key("Float", "lh_distance"):
                var entry = cfg.get_value("Float", "lh_distance")
                if entry is Dictionary:
                        entry["value"] = _current_distance
                        cfg.set_value("Float", "lh_distance", entry)

        # Update Bool values
        if cfg.has_section_key("Bool", "lh_enabled"):
                var entry = cfg.get_value("Bool", "lh_enabled")
                if entry is Dictionary:
                        entry["value"] = _user_enabled
                        cfg.set_value("Bool", "lh_enabled", entry)

        if cfg.has_section_key("Bool", "lh_shelter_auto"):
                var entry = cfg.get_value("Bool", "lh_shelter_auto")
                if entry is Dictionary:
                        entry["value"] = _shelter_auto
                        cfg.set_value("Bool", "lh_shelter_auto", entry)

        if cfg.has_section_key("Bool", "lh_enemy_weapons"):
                var entry = cfg.get_value("Bool", "lh_enemy_weapons")
                if entry is Dictionary:
                        entry["value"] = _enemy_weapons
                        cfg.set_value("Bool", "lh_enemy_weapons", entry)

        # Update Keycode
        if cfg.has_section_key("Keycode", "lh_toggle_key"):
                var entry = cfg.get_value("Keycode", "lh_toggle_key")
                if entry is Dictionary:
                        entry["value"] = lh_settings.toggle_key
                        cfg.set_value("Keycode", "lh_toggle_key", entry)

        # Update Custom Locations string
        if cfg.has_section_key("String", "lh_custom_shelters"):
                var entry = cfg.get_value("String", "lh_custom_shelters")
                if entry is Dictionary:
                        entry["value"] = lh_settings.custom_shelters
                        cfg.set_value("String", "lh_custom_shelters", entry)

        cfg.save(MCM_CONFIG_PATH)
        _log("[LH] Settings saved to MCM config")

# ═══════════════════════════════════════════════════════════════════
# INPUT — toggle key opens/closes GUI, keybind capture, TAB scan
# ═══════════════════════════════════════════════════════════════════

func _handle_keybind_event(event: InputEventKey) -> bool:
        if not _listening_for_keybind:
                return false
        if event.keycode == KEY_ESCAPE:
                _listening_for_keybind = false
                _keybind_btn.text = OS.get_keycode_string(_toggle_key)
                _keybind_btn.grab_focus()
                _log("[LH] Keybind capture cancelled")
                return true
        elif event.keycode != 0:
                _finish_keybind_capture(event.keycode)
                return true
        return false

func _input(event: InputEvent) -> void:
        if event is InputEventKey and event.pressed and not event.echo:
                # Keybind capture mode
                if _handle_keybind_event(event):
                        get_viewport().set_input_as_handled()
                        return
                # Normal: toggle GUI
                if event.keycode == _toggle_key:
                        _toggle_gui()
                        get_viewport().set_input_as_handled()
                        return
                # Manual full-map scan
                if event.keycode == SCAN_KEY:
                        _full_scan(false)

# ═══════════════════════════════════════════════════════════════════
# SHELTER DETECTION
# ═══════════════════════════════════════════════════════════════════

func _check_scene_change() -> void:
        var scene = get_tree().current_scene
        if scene == null:
                return

        var scene_name: String = scene.name.to_lower()
        var scene_path: String = scene.scene_file_path.to_lower() if scene.scene_file_path else ""
        var combined: String = scene_name + "|" + scene_path

        if combined == _last_scene_name:
                return

        _last_scene_name = combined

        _in_shelter = _is_shelter_scene(scene_name) or _is_shelter_scene(scene_path)
        _log("[LH] Scene: name=" + scene_name + " path=" + scene_path + " shelter=" + str(_in_shelter))

        if is_instance_valid(_scene_info_label):
                _scene_info_label.text = "Scene: " + scene_name + (" [Shelter]" if _in_shelter else "")

        var now_active: bool = _is_active()

        if not now_active:
                _log("[LH] Entering shelter -> removing outlines")
                _safe_remove_all_outlines()
        else:
                _log("[LH] Scene changed / leaving shelter -> scanning for loot")
                _full_scan(true)

func _is_shelter_scene(text: String) -> bool:
        # Split by path separator, then break apart by word separators
        var tokens := text.split("/", false)
        var all_words: PackedStringArray = []
        for token in tokens:
                var parts := token.replace(".", " ").replace("_", " ").replace("-", " ").split(" ", false)
                for p in parts:
                        var w := p.strip_edges()
                        if w != "":
                                all_words.append(w)
        # Exact word match — "apartment" won't match "apartments"
        for shelter in SHELTER_SCENES:
                if shelter in all_words:
                        return true
        for kw in _custom_shelter_list:
                if kw in all_words:
                        return true
        return false

## Re-evaluates shelter status from the cached scene identifiers without
## needing an actual scene transition. Called after the custom list changes.
func _recheck_shelter() -> void:
        if _last_scene_name == "":
                return
        var parts := _last_scene_name.split("|", false)
        var sname: String = parts[0] if parts.size() > 0 else ""
        var spath: String = parts[1] if parts.size() > 1 else ""
        var was_in: bool = _in_shelter
        _in_shelter = _is_shelter_scene(sname) or _is_shelter_scene(spath)
        if was_in == _in_shelter:
                return
        if is_instance_valid(_scene_info_label):
                _scene_info_label.text = "Scene: " + sname + (" [Shelter]" if _in_shelter else "")
        if not _is_active():
                _log("[LH] _recheck_shelter: now in shelter -> removing outlines")
                _safe_remove_all_outlines()
        else:
                _log("[LH] _recheck_shelter: left shelter -> scanning")
                _full_scan(true)

# ═══════════════════════════════════════════════════════════════════
# SCENE TRANSITION SAFETY
# ═══════════════════════════════════════════════════════════════════


func _on_node_added(node: Node) -> void:
        if not _is_active():
                return
        if not (node is Node3D):
                return
        if node.get_script() == null:
                return
        call_deferred("_deferred_new_node_check", node)

func _deferred_new_node_check(node: Node) -> void:
        if not is_instance_valid(node) or not node.is_inside_tree():
                return
        # Second defer — parent chain may still be settling
        call_deferred("_deferred_new_node_check2", node)

func _deferred_new_node_check2(node: Node) -> void:
        if not is_instance_valid(node) or not node.is_inside_tree():
                return
        # Walk ancestors looking for a CharacterBody3D.
        var n = node.get_parent()
        while n != null and is_instance_valid(n):
                if n is CharacterBody3D:
                        if not (_enemy_weapons and _is_dead_body(n as CharacterBody3D)):
                                return  # live NPC (or unknown) → skip
                        break  # detected corpse → let it through
                n = n.get_parent()
        # Block nodes that belong to the camera's hierarchy (first-person rig)
        var camera = _find_camera()
        if camera != null:
                if camera.is_ancestor_of(node) or node.is_ancestor_of(camera):
                        return
        if node.get_script() == null:
                return
        _check_node(node)

func _on_item_removed(node: Node) -> void:
        _log("[LH] _on_item_removed: " + str(node) + " id=" + str(node.get_instance_id()))
        _highlighted.erase(node.get_instance_id())

func _reset_tracking() -> void:
        _log("[LH] _reset_tracking (highlighted=" + str(_highlighted.size()) + " rejected=" + str(_rejected.size()) + ")")
        _highlighted.clear()
        _rejected.clear()
        _excluded_ancestors.clear()

# ═══════════════════════════════════════════════════════════════════
# DEAD BODY DETECTION — heuristics only, no game-internal API
# ═══════════════════════════════════════════════════════════════════


func _is_dead_body(body: CharacterBody3D) -> bool:
        # Pattern 1 – explicit dead flag (dead = true)
        var dead_val = body.get("dead")
        if dead_val == true:
                return true

        # Pattern 2 – is_alive() method returns false
        if body.has_method("is_alive") and not body.is_alive():
                return true

        # Pattern 3 – alive property is false
        var alive_val = body.get("alive")
        if alive_val == false:
                return true

        # Pattern 4 – health / hp numeric property at or below 0
        var hp = body.get("health")
        if (hp is float or hp is int) and hp <= 0:
                return true
        var hp2 = body.get("hp")
        if (hp2 is float or hp2 is int) and hp2 <= 0:
                return true

        # Pattern 5 – currentHealth / current_health
        var hp3 = body.get("currentHealth")
        if (hp3 is float or hp3 is int) and hp3 <= 0:
                return true
        var hp4 = body.get("current_health")
        if (hp4 is float or hp4 is int) and hp4 <= 0:
                return true

        return false

# ═══════════════════════════════════════════════════════════════════
# FULL MAP SCAN
# ═══════════════════════════════════════════════════════════════════

## Triggers a full map scan.
##   reset=true:  clears all existing outlines, re-scans everything (scene change / shelter exit)
##   reset=false: keeps existing outlines, only scans for NEW items (TAB press)
func _full_scan(reset: bool = true) -> void:
        if not _is_active():
                _log("[LH] _full_scan SKIPPED (not active)")
                return
        _log("[LH] _full_scan START (reset=" + str(reset) + ", frame-spread)")
        if reset:
                _safe_remove_all_outlines()
        else:
                _rejected.clear()
        _prewarm_exclusions()
        _scan_queue.clear()
        var root: Node = get_tree().current_scene
        if root == null:
                root = get_tree().root
        if root != null:
                _gather_all_nodes(root)
        _scan_active = _scan_queue.size() > 0
        _log("[LH] _full_scan queued " + str(_scan_queue.size()) + " candidates")

## Gather every node in the tree for scanning (no distance filter).
func _gather_all_nodes(node: Node, depth: int = 0) -> void:
        if depth > 10 or not is_instance_valid(node):
                return
        if node is CanvasLayer or node is Control:
                return
        if node is CharacterBody3D:
                if _enemy_weapons and _is_dead_body(node as CharacterBody3D):
                        for child in node.get_children():
                                _gather_all_nodes(child, depth + 1)
                return
        if node.has_meta("_lh_outline"):
                return
        var oid: int = node.get_instance_id()
        if oid in _excluded_ancestors and _excluded_ancestors[oid]:
                return
        _scan_queue.append(node)
        for child in node.get_children():
                _gather_all_nodes(child, depth + 1)

## Pre-cache exclusion ancestors so _is_excluded hits cache immediately.
func _prewarm_exclusions() -> void:
        var root = get_tree().current_scene
        if root == null:
                return
        _prewarm_node(root, 0)

func _prewarm_node(node: Node, depth: int) -> void:
        if depth > 4 or not is_instance_valid(node):
                return
        var oid: int = node.get_instance_id()
        if oid in _excluded_ancestors:
                return
        if node is CharacterBody3D:
                if _enemy_weapons and _is_dead_body(node as CharacterBody3D):
                        _excluded_ancestors[oid] = false
                        for child in node.get_children():
                                _prewarm_node(child, depth + 1)
                else:
                        _excluded_ancestors[oid] = true
                return
        var name_low: String = node.name.to_lower()
        for pattern in _EXCLUDED_NAMES:
                if pattern.begins_with("=") and pattern.ends_with("="):
                        var exact_name: String = pattern.substr(1, pattern.length() - 2).to_lower()
                        if name_low == exact_name:
                                _excluded_ancestors[oid] = true
                                return
                else:
                        if pattern in name_low:
                                _excluded_ancestors[oid] = true
                                return
        _excluded_ancestors[oid] = false
        for child in node.get_children():
                _prewarm_node(child, depth + 1)

## Process scan queue spread across frames to avoid stutter.
func _process_scan_queue() -> void:
        if not _scan_active or _scan_queue.is_empty():
                _scan_active = false
                return
        var processed := 0
        while processed < SCAN_NODES_PER_FRAME and not _scan_queue.is_empty():
                var node: Node = _scan_queue.pop_back()
                processed += 1
                if not is_instance_valid(node) or not node.is_inside_tree():
                        continue
                if node.has_meta("_lh_outline"):
                        continue
                _check_node(node)
        if _scan_queue.is_empty():
                _scan_active = false

# ═══════════════════════════════════════════════════════════════════
# NODE CHECK — determines if a node is loot and adds outline
# ═══════════════════════════════════════════════════════════════════

func _check_node(node: Node) -> void:
        if not _is_active():
                return
        if not is_instance_valid(node) or not node.is_inside_tree():
                return
        var oid = node.get_instance_id()
        if _highlighted.has(oid) or _rejected.has(oid):
                return
        if not (node is Node3D):
                return
        if node.get_script() == null:
                return

        _log("[LH] _check_node evaluating: " + str(node.name) + " path=" + str(node.get_path()))

        if not ("slotData" in node or node is RigidBody3D or node.has_method("Unfreeze")):
                _rejected[oid] = true
                return
        if _is_excluded(node):
                _log("[LH]   -> excluded: " + str(node.name))
                _rejected[oid] = true
                return

        if not is_instance_valid(node) or not node.is_inside_tree():
                _log("[LH]   -> gone before outline (freed during checks)")
                return

        _log("[LH]   -> ADDING outline to: " + str(node.name))
        var outlines = _add_outline(node)
        if outlines.size() > 0:
                _highlighted[oid] = {"node": node, "outlines": outlines}
                if node.is_inside_tree():
                        if not node.tree_exited.is_connected(_on_item_removed):
                                node.tree_exited.connect(_on_item_removed.bind(node))
                _log("[LH]   -> OK, " + str(outlines.size()) + " outlines added")
        else:
                _log("[LH]   -> no meshes found, rejected")
                _rejected[oid] = true

# ═══════════════════════════════════════════════════════════════════
# _PROCESS — scan queue processing + distance culling + scene check
# ═══════════════════════════════════════════════════════════════════

func _process(_delta: float) -> void:
        _frame_counter += 1

        if _gui_visible:
                if Input.mouse_mode != Input.MOUSE_MODE_VISIBLE:
                        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

        if _frame_counter % 30 == 0:
                _check_scene_change()

        # Apply any settings written by MCM via the shared resource
        if lh_settings.dirty:
                lh_settings.dirty = false
                _mcm_syncing = true
                _on_color_changed(lh_settings.color)
                _on_thickness_changed(lh_settings.grow)
                _on_brightness_changed(lh_settings.brightness)
                _on_distance_changed(lh_settings.distance)
                _on_enable_toggled(lh_settings.enabled)
                _on_shelter_toggled(lh_settings.shelter_auto)
                _on_enemy_weapons_toggled(lh_settings.enemy_weapons)
                _toggle_key = lh_settings.toggle_key if lh_settings.toggle_key > 0 else DEFAULT_TOGGLE_KEY
                _mcm_syncing = false
                # Sync F7 GUI controls to reflect the new values
                if _color_btn:           _color_btn.color = lh_settings.color
                if _thickness_slider:    _thickness_slider.value = lh_settings.grow
                if _brightness_slider:   _brightness_slider.value = lh_settings.brightness
                if _distance_slider:     _distance_slider.value = lh_settings.distance
                if _enable_check:        _enable_check.button_pressed = lh_settings.enabled
                if _shelter_check:       _shelter_check.button_pressed = lh_settings.shelter_auto
                if _enemy_weapons_check: _enemy_weapons_check.button_pressed = lh_settings.enemy_weapons
                if _keybind_btn:         _keybind_btn.text = OS.get_keycode_string(_toggle_key)
                # Pick up MCM custom shelters changes
                _parse_custom_shelters()
                if _shelter_content != null and _shelter_content.visible:
                        _refresh_shelter_list_gui()
                _recheck_shelter()

        if not _is_active():
                return

        # Process scan queue (spread across frames)
        _process_scan_queue()

        if _current_distance <= 0.0:
                return
        if _highlighted.is_empty():
                return
        if _frame_counter % 10 != 0:
                return

        var camera = _find_camera()
        if camera == null:
                return

        var cam_pos = camera.global_position
        if cam_pos == Vector3.ZERO:
                return

        var max_dist_sq: float = _current_distance * _current_distance

        var keys = _highlighted.keys()
        for oid in keys:
                if not _highlighted.has(oid):
                        continue
                var entry: Dictionary = _highlighted[oid]
                var item_node: Variant = entry.get("node")
                if item_node == null or not is_instance_valid(item_node) or not item_node.is_inside_tree():
                        _log("[LH] _process: pruning dead entry oid=" + str(oid))
                        _highlighted.erase(oid)
                        continue

                var dist_sq: float = item_node.global_position.distance_squared_to(cam_pos)
                var in_range: bool = dist_sq <= max_dist_sq

                var outlines: Array = entry.get("outlines", [])
                for ol in outlines:
                        if is_instance_valid(ol):
                                ol.visible = in_range

# ═══════════════════════════════════════════════════════════════════
# SAFE OUTLINE REMOVAL
# ═══════════════════════════════════════════════════════════════════

func _safe_remove_all_outlines() -> void:
        _log("[LH] _safe_remove_all_outlines (count=" + str(_highlighted.size()) + ")")
        for oid in _highlighted.keys():
                var entry: Dictionary = _highlighted[oid]
                var item_node: Variant = entry.get("node")
                if item_node != null and is_instance_valid(item_node):
                        _remove_outlines_from_node(item_node)
        _reset_tracking()

func _remove_outlines_from_node(node: Node) -> void:
        var to_remove: Array[Node] = []
        _find_outline_children(node, to_remove)
        _log("[LH] _remove_outlines_from_node: " + str(node.name) + " removing " + str(to_remove.size()))
        for child in to_remove:
                if is_instance_valid(child) and child.get_parent() != null:
                        child.get_parent().remove_child(child)
                        child.free()

func _find_outline_children(node: Node, list: Array[Node]) -> void:
        for child in node.get_children():
                if not is_instance_valid(child):
                        continue
                if child.has_meta("_lh_outline"):
                        list.append(child)
                else:
                        _find_outline_children(child, list)

# ═══════════════════════════════════════════════════════════════════
# OUTLINE APPLICATION
# ═══════════════════════════════════════════════════════════════════

func _add_outline(node: Node) -> Array:
        var outlines: Array = []
        var meshes = _find_all_meshes(node)
        _log("[LH] _add_outline: " + str(node.name) + " meshes_found=" + str(meshes.size()))
        for mesh: MeshInstance3D in meshes:
                if not is_instance_valid(mesh) or not mesh.is_inside_tree():
                        _log("[LH]   mesh gone mid-loop: " + str(mesh))
                        continue
                if not mesh.mesh:
                        continue
                var has_outline := false
                for child in mesh.get_children():
                        if child.has_meta("_lh_outline"):
                                has_outline = true
                                break
                if has_outline:
                        continue

                var outline := MeshInstance3D.new()
                outline.mesh = mesh.mesh
                outline.material_override = _outline_mat
                outline.no_depth_test = true
                outline.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
                outline.render_priority = 1
                outline.set_meta("_lh_outline", true)
                if is_instance_valid(mesh) and mesh.is_inside_tree():
                        mesh.add_child(outline)
                        outlines.append(outline)
                else:
                        _log("[LH]   mesh died before add_child: " + str(mesh))
                        outline.free()
        return outlines

## Finds the active Camera3D across all viewports.
func _find_camera() -> Camera3D:
        var cam = get_viewport().get_camera_3d()
        if cam != null:
                return cam
        # Fallback: walk all viewports to find the active camera
        for vp in get_tree().root.get_children():
                if vp is SubViewportContainer or vp is SubViewport:
                        var sub = vp if vp is SubViewport else vp.get_child(0)
                        if sub is SubViewport:
                                cam = sub.get_camera_3d()
                                if cam != null:
                                        return cam
        # Last resort: find any current Camera3D in the scene tree
        for node in get_tree().get_nodes_in_group("cameras"):
                if node is Camera3D and node.current:
                        return node
        return null

func get_material() -> ShaderMaterial:
        return _outline_mat

## Called by LootHighlightConfig whenever MCM settings are saved.
## Reads from the shared LH_Settings resource and applies all values.
func sync_settings() -> void:
        _mcm_syncing = true
        _on_color_changed(lh_settings.color)
        _on_thickness_changed(lh_settings.grow)
        _on_brightness_changed(lh_settings.brightness)
        _on_distance_changed(lh_settings.distance)
        _on_enable_toggled(lh_settings.enabled)
        _on_shelter_toggled(lh_settings.shelter_auto)
        _enemy_weapons = lh_settings.enemy_weapons
        _toggle_key = lh_settings.toggle_key if lh_settings.toggle_key > 0 else DEFAULT_TOGGLE_KEY
        if _keybind_btn:
                _keybind_btn.text = OS.get_keycode_string(_toggle_key)
        if _enemy_weapons_check:
                _enemy_weapons_check.button_pressed = _enemy_weapons
        _parse_custom_shelters()
        if _shelter_content != null and _shelter_content.visible:
                _refresh_shelter_list_gui()
        _mcm_syncing = false

# ═══════════════════════════════════════════════════════════════════
# EXCLUSION FILTER
# ═══════════════════════════════════════════════════════════════════

const _EXCLUDED_NAMES := ["player", "characterbody3d", "camera", "=police=", "apc", "btr", "hand", "fp_", "firstperson", "weapon_holder", "ai_", "characterbody", "display"]

func _is_excluded(node: Node) -> bool:
        var n = node
        var safety := 0
        while n != null and is_instance_valid(n) and safety < 15:
                var oid = n.get_instance_id()
                if oid in _excluded_ancestors:
                        return _excluded_ancestors[oid]
                var name_low: String = n.name.to_lower()

                if n is CharacterBody3D:
                        if _enemy_weapons and _is_dead_body(n as CharacterBody3D):
                                _excluded_ancestors[oid] = false
                                return false
                        else:
                                _excluded_ancestors[oid] = true
                                return true

                for pattern in _EXCLUDED_NAMES:
                        if pattern.begins_with("=") and pattern.ends_with("="):
                                var exact_name: String = pattern.substr(1, pattern.length() - 2).to_lower()
                                if name_low == exact_name:
                                        _excluded_ancestors[oid] = true
                                        return true
                        else:
                                if pattern in name_low:
                                        _excluded_ancestors[oid] = true
                                        return true

                _excluded_ancestors[oid] = false
                n = n.get_parent()
                safety += 1
        return false

# ═══════════════════════════════════════════════════════════════════
# MESH HELPERS
# ═══════════════════════════════════════════════════════════════════

func _find_all_meshes(node: Node) -> Array[MeshInstance3D]:
        var out: Array[MeshInstance3D] = []
        _collect_meshes(node, out)
        return out

func _collect_meshes(node: Node, out: Array[MeshInstance3D]) -> void:
        if not is_instance_valid(node):
                return
        if node is MeshInstance3D:
                out.append(node as MeshInstance3D)
                return
        for child: Node in node.get_children():
                _collect_meshes(child, out)
