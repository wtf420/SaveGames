extends Resource
class_name LH_Settings

var dirty: bool = false  # set true by Config.gd; cleared by Main.gd after applying

var color: Color = Color(1.0, 1.0, 1.0, 1.0)
var grow: float = 0.002
var brightness: float = 0.2
var distance: float = 20.0
var enabled: bool = true
var shelter_auto: bool = true
var toggle_key: int = 4194338  # KEY_F7
var enemy_weapons: bool = true
var custom_shelters: String = "apartment"
