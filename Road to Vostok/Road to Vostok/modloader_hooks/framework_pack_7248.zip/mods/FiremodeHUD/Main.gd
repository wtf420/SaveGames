extends Node

const MOD_ID: String = "FiremodeHUD"
const FILE_PATH: String = "user://MCM/FiremodeHUD/"
const CONFIG_FILE: String = FILE_PATH + "config.ini"
const UI_FONT: Font = preload("res://Fonts/Lora-Regular.ttf")

const BASE_RES_X: float = 1920.0
const BASE_RES_Y: float = 1080.0
const BASE_POS_X: float = 1520.0
const BASE_POS_Y: float = 972.0
const DEFAULT_SIZE: int = 28
const CUSTOM_FONTS_SETTINGS_PATH: String = "res://mods/CustomFonts/Config/CustomFontsSettings.tres"

const INSPECT_ACTIONS: PackedStringArray = [
	"inspect",
	"weapon_inspect",
	"check_weapon",
	"inspection",
	"weapon_check"
]

const INSPECT_GAME_DATA_FLAGS: PackedStringArray = [
	"isInspecting",
	"inspecting",
	"inspect",
	"isInspect",
	"weaponInspect",
	"inInspection",
	"isInspection"
]

const DISPLAY_TIME: float = 0.55
const FADE_IN_TIME: float = 0.18
const FADE_OUT_TIME: float = 0.35

var gameData: Resource = preload("res://Resources/GameData.tres")
var _config: ConfigFile = ConfigFile.new()

var _default_pos_x: int = int(BASE_POS_X)
var _default_pos_y: int = int(BASE_POS_Y)

var pos_x: int = int(BASE_POS_X)
var pos_y: int = int(BASE_POS_Y)
var text_size: int = DEFAULT_SIZE
var lock_to_scaled_anchor: bool = true

var _ui_layer: CanvasLayer
var _label: Label
var _mode_last: int = -999
var _display_tween: Tween
var _inspect_last: bool = false
var _last_screen_size: Vector2i = Vector2i.ZERO
var _custom_fonts_settings: Resource

func _ready() -> void:
	_build_defaults()
	_load_or_create_config()
	_apply_config_values()
	_register_mcm()
	_create_overlay()
	_apply_display_settings()
	_try_connect_custom_fonts()
	_try_apply_custom_font()

	_last_screen_size = _get_monitor_size()
	_inspect_last = _is_inspecting_now()

	# Prime with current game state so we only show when it changes later.
	if gameData and "firemode" in gameData:
		_mode_last = int(gameData.firemode)

func _process(_delta: float) -> void:
	var screen_size_now: Vector2i = _get_monitor_size()
	if screen_size_now != _last_screen_size:
		_last_screen_size = screen_size_now
		_apply_display_settings()

	if _did_trigger_inspect_input():
		_show_current_mode_text()

	var inspect_now: bool = _is_inspecting_now()
	if inspect_now and not _inspect_last:
		_show_current_mode_text()
	_inspect_last = inspect_now

	if not gameData or not ("firemode" in gameData):
		return

	var mode_now: int = int(gameData.firemode)
	if mode_now == _mode_last:
		return

	_mode_last = mode_now
	_show_mode_text(_mode_to_text(mode_now))

func _create_overlay() -> void:
	_ui_layer = CanvasLayer.new()
	_ui_layer.layer = 100
	add_child(_ui_layer)

	_label = Label.new()
	_label.text = ""
	_label.visible = false
	_label.position = Vector2(pos_x, pos_y)
	_label.modulate = Color(1, 1, 1, 0)
	_label.add_theme_font_override("font", UI_FONT)
	_label.add_theme_font_size_override("font_size", text_size)
	_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	_label.add_theme_constant_override("shadow_offset_x", 2)
	_label.add_theme_constant_override("shadow_offset_y", 2)
	_ui_layer.add_child(_label)

func _build_defaults() -> void:
	var screen_size: Vector2i = _get_monitor_size()
	var max_x: int = max(1, screen_size.x)
	var max_y: int = max(1, screen_size.y)
	var max_size: int = max(24, int(screen_size.y * 0.25))

	_update_default_anchor_for_screen(screen_size)

	_config.set_value("Category", "Display", {"menu_pos": 1})

	_config.set_value("Int", "position_x", {
		"name": "Position X",
		"tooltip": "Horizontal screen position in pixels.",
		"category": "Display",
		"menu_pos": 1,
		"default": _default_pos_x,
		"value": _default_pos_x,
		"minRange": 0,
		"maxRange": max_x,
		"on_value_changed": "_on_setting_preview",
	})

	_config.set_value("Int", "position_y", {
		"name": "Position Y",
		"tooltip": "Vertical screen position in pixels.",
		"category": "Display",
		"menu_pos": 2,
		"default": _default_pos_y,
		"value": _default_pos_y,
		"minRange": 0,
		"maxRange": max_y,
		"on_value_changed": "_on_setting_preview",
	})

	_config.set_value("Int", "size", {
		"name": "Text Size",
		"tooltip": "Font size of the firemode label.",
		"category": "Display",
		"menu_pos": 3,
		"default": DEFAULT_SIZE,
		"value": DEFAULT_SIZE,
		"minRange": 10,
		"maxRange": max_size,
		"on_value_changed": "_on_setting_preview",
	})

	_config.set_value("Bool", "lock_to_scaled_anchor", {
		"name": "Lock Position To Resolution",
		"tooltip": "Keeps the HUD at the same relative monitor location (1520x972 at 1920x1080).",
		"category": "Display",
		"menu_pos": 4,
		"default": true,
		"value": true,
		"on_value_changed": "_on_setting_preview",
	})

func _update_default_anchor_for_screen(screen_size: Vector2i) -> void:
	var max_x: int = max(1, screen_size.x)
	var max_y: int = max(1, screen_size.y)
	_default_pos_x = clampi(int(round((BASE_POS_X / BASE_RES_X) * float(max_x))), 0, max_x)
	_default_pos_y = clampi(int(round((BASE_POS_Y / BASE_RES_Y) * float(max_y))), 0, max_y)

func _get_monitor_size() -> Vector2i:
	var window_size: Vector2i = DisplayServer.window_get_size()
	if window_size.x > 0 and window_size.y > 0:
		return window_size

	var screen_index: int = DisplayServer.window_get_current_screen()
	if screen_index < 0:
		screen_index = 0
	return DisplayServer.screen_get_size(screen_index)

func _load_or_create_config() -> void:
	var mcm: Resource = load("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres") \
		if ResourceLoader.exists("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres") \
		else null

	if not FileAccess.file_exists(CONFIG_FILE):
		DirAccess.open("user://").make_dir_recursive(FILE_PATH)
		_config.save(CONFIG_FILE)
	else:
		if mcm:
			mcm.CheckConfigurationHasUpdated(MOD_ID, _config, CONFIG_FILE)
		_config.load(CONFIG_FILE)

func _apply_config_values() -> void:
	var screen_size: Vector2i = _get_monitor_size()
	var max_x: int = max(1, screen_size.x)
	var max_y: int = max(1, screen_size.y)
	_update_default_anchor_for_screen(screen_size)

	lock_to_scaled_anchor = bool(_config.get_value("Bool", "lock_to_scaled_anchor", {}).get("value", true))
	if lock_to_scaled_anchor:
		pos_x = _default_pos_x
		pos_y = _default_pos_y
	else:
		pos_x = clampi(int(_config.get_value("Int", "position_x", {}).get("value", _default_pos_x)), 0, max_x)
		pos_y = clampi(int(_config.get_value("Int", "position_y", {}).get("value", _default_pos_y)), 0, max_y)
	text_size = int(_config.get_value("Int", "size", {}).get("value", DEFAULT_SIZE))

func _apply_display_settings() -> void:
	if not _label:
		return

	if lock_to_scaled_anchor:
		_update_default_anchor_for_screen(_get_monitor_size())
		pos_x = _default_pos_x
		pos_y = _default_pos_y

	_label.position = _window_pixels_to_canvas_position(pos_x, pos_y)
	_label.add_theme_font_size_override("font_size", text_size)

func _window_pixels_to_canvas_position(px_x: int, px_y: int) -> Vector2:
	var window_size: Vector2i = DisplayServer.window_get_size()
	if window_size.x <= 0 or window_size.y <= 0:
		return Vector2(px_x, px_y)

	var canvas_size: Vector2 = get_viewport().get_visible_rect().size
	if canvas_size.x <= 0.0 or canvas_size.y <= 0.0:
		return Vector2(px_x, px_y)

	var scaled_x: float = float(px_x) * (canvas_size.x / float(window_size.x))
	var scaled_y: float = float(px_y) * (canvas_size.y / float(window_size.y))
	return Vector2(scaled_x, scaled_y)

func _register_mcm() -> void:
	if not ResourceLoader.exists("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres"):
		return
	var mcm: Resource = load("res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres")
	if not mcm:
		return

	mcm.RegisterConfiguration(
		MOD_ID,
		"Firemode HUD",
		FILE_PATH,
		"Configure on-screen firemode indicator position and size.",
		UpdateConfigProperties,
		self
	)

func _show_mode_text(text: String) -> void:
	if text.is_empty():
		return
	if _display_tween and _display_tween.is_running():
		_display_tween.kill()

	_label.text = text
	_label.visible = true
	_label.modulate.a = 0.0

	_display_tween = create_tween()
	_display_tween.tween_property(_label, "modulate:a", 1.0, FADE_IN_TIME)
	_display_tween.tween_interval(DISPLAY_TIME)
	_display_tween.tween_property(_label, "modulate:a", 0.0, FADE_OUT_TIME)
	_display_tween.finished.connect(func() -> void:
		_label.visible = false
	)

func _is_gun_rig_active() -> bool:
	var manager: Node = get_node_or_null("/root/Map/Core/Camera/Manager")
	if not manager or manager.get_child_count() == 0:
		return false
	var rig: Node = manager.get_child(manager.get_child_count() - 1)
	return rig != null and "slotData" in rig

func _show_current_mode_text() -> void:
	if not _is_gun_rig_active():
		return
	if not gameData or not ("firemode" in gameData):
		return
	_show_mode_text(_mode_to_text(int(gameData.firemode)))

func _did_trigger_inspect_input() -> bool:
	for action_name in INSPECT_ACTIONS:
		if InputMap.has_action(action_name) and Input.is_action_just_pressed(action_name):
			return true
	return false

func _is_inspecting_now() -> bool:
	if not gameData:
		return false

	for flag_name in INSPECT_GAME_DATA_FLAGS:
		if flag_name in gameData and bool(gameData.get(flag_name)):
			return true

	return false

func _try_connect_custom_fonts() -> void:
	if not ResourceLoader.exists(CUSTOM_FONTS_SETTINGS_PATH):
		return

	if not _custom_fonts_settings:
		_custom_fonts_settings = load(CUSTOM_FONTS_SETTINGS_PATH)

	if not _custom_fonts_settings:
		return

	if _custom_fonts_settings.has_signal("changed") and not _custom_fonts_settings.changed.is_connected(_on_custom_fonts_changed):
		_custom_fonts_settings.changed.connect(_on_custom_fonts_changed)

func _on_custom_fonts_changed() -> void:
	_try_apply_custom_font()

func _try_apply_custom_font() -> void:
	if not _label:
		return

	var selected_font: Font = UI_FONT
	var custom_font: Font = _resolve_custom_font()
	if custom_font:
		selected_font = custom_font

	_label.add_theme_font_override("font", selected_font)

func _resolve_custom_font() -> Font:
	if not ResourceLoader.exists(CUSTOM_FONTS_SETTINGS_PATH):
		return null

	if not _custom_fonts_settings:
		_custom_fonts_settings = load(CUSTOM_FONTS_SETTINGS_PATH)

	if not _custom_fonts_settings:
		return null

	if not ("FONT_REGISTRY" in _custom_fonts_settings and "font_id" in _custom_fonts_settings):
		return null

	var registry: Dictionary = _custom_fonts_settings.FONT_REGISTRY
	if registry.is_empty():
		return null

	var font_id: String = str(_custom_fonts_settings.font_id)
	var family: Dictionary = registry.get(font_id, {})
	var regular_path: String = str(family.get("regular", ""))

	if regular_path == "" or not ResourceLoader.exists(regular_path):
		return null

	var loaded_font: Font = load(regular_path)
	return loaded_font

func _mode_to_text(mode_value: int) -> String:
	match mode_value:
		0:
			return ""
		1:
			return "FIREMODE: SEMI"
		2:
			return "FIREMODE: AUTO"
		3:
			return "FIREMODE: BURST"
		_:
			return "FIREMODE: " + str(mode_value)

# Called by MCM when the player saves changes.
func UpdateConfigProperties(config: ConfigFile) -> void:
	_config = config
	_apply_config_values()
	_apply_display_settings()
	_hide_preview()

# Called by MCM in real time as the player moves a slider.
func _on_setting_preview(valueId: String, newValue, _menu: Object) -> void:
	var screen_size: Vector2i = _get_monitor_size()
	match valueId:
		"position_x":
			pos_x = clampi(int(newValue), 0, max(1, screen_size.x))
		"position_y":
			pos_y = clampi(int(newValue), 0, max(1, screen_size.y))
		"size":
			text_size = int(newValue)
		"lock_to_scaled_anchor":
			lock_to_scaled_anchor = bool(newValue)
	_show_preview()
	_apply_display_settings()

func _show_preview() -> void:
	if not _label:
		return
	if _display_tween and _display_tween.is_running():
		_display_tween.kill()
	_label.text = "FIREMODE: SEMI"
	_label.visible = true
	_label.modulate.a = 1.0

func _hide_preview() -> void:
	if not _label:
		return
	_label.visible = false
	_label.modulate.a = 0.0
