extends Node

const MOD_ID := "MedicalDurability"
const USES_INITIALIZED_META := "_md_uses_initialized"
const MCM_HELPERS_CANDIDATES := [
    "res://ModConfigurationMenu/Scripts/Doink Oink/MCM_Helpers.tres",
    "res://Mod Configuration Menu/Scripts/Doink Oink/MCM_Helpers.tres"
]
const MCM_CONFIG_DIR := "user://MCM/MedicalDurability"
const MCM_CONFIG_FILE := MCM_CONFIG_DIR + "/config.ini"

const DEFAULT_ITEM_USES := {
    "Bandage_Improvised": 2,
    "Bandage": 3,
    "Splint_Improvised": 2,
    "Splint": 3,
    "Tourniquet_Improvised": 3,
    "Tourniquet": 5,
    "Painkillers": 6,
    "Antibiotics": 4,
    "Antiseptic": 5,
    "Medkit": 8,
    "IFAK": 6,
    "AFAK": 7,
    "Saline": 2,
    "Cold_Medicine": 4,
    "Lotion": 4,
    "Balm": 4,
    "Melatonin": 6,
    "Wipes": 8,
    "Tissues": 8,
    "Deodorant": 10
}
var item_uses := DEFAULT_ITEM_USES.duplicate(true)
var item_uses_lookup := {}
var randomize_initial_uses := false
var initial_uses_max_ratio := 0.5
var _rng := RandomNumberGenerator.new()
var _bootstrapped := false

func _notification(what: int) -> void:
    if what != NOTIFICATION_READY:
        return
    if _bootstrapped:
        return
    _bootstrapped = true
    _bootstrap_mod()

func _bootstrap_mod() -> void:
    _rng.randomize()
    _initialize_mcm_configuration()
    _build_item_uses_lookup()
    _override_script("res://MedicalDurability/Interface.gd")
    _override_script("res://MedicalDurability/Item.gd")
    _override_script("res://MedicalDurability/Tooltip.gd")
    Engine.set_meta(MOD_ID, self)
    call_deferred("_refresh_open_interface_items")
    print("[MedicalDurability] loaded")

func _initialize_mcm_configuration() -> void:
    item_uses = DEFAULT_ITEM_USES.duplicate(true)

    var helpers := _load_mcm_helpers()
    if helpers == null:
        print("[MedicalDurability] MCM helper not found. Skipping MCM registration.")
        return

    var config := ConfigFile.new()
    _build_mcm_config_schema(config)

    if !FileAccess.file_exists(MCM_CONFIG_FILE):
        var user_dir := DirAccess.open("user://")
        if user_dir:
            user_dir.make_dir_recursive("MCM/MedicalDurability")
        config.save(MCM_CONFIG_FILE)
    else:
        if helpers.has_method(&"CheckConfigurationHasUpdated"):
            helpers.call(&"CheckConfigurationHasUpdated", MOD_ID, config, MCM_CONFIG_FILE)
        elif helpers.has_method(&"CheckConfigruationHasUpdated"):
            helpers.call(&"CheckConfigruationHasUpdated", MOD_ID, config, MCM_CONFIG_FILE)
        config.load(MCM_CONFIG_FILE)

    _apply_item_uses_from_config(config)

    var register_method: StringName = &""
    if helpers.has_method(&"RegisterConfiguration"):
        register_method = &"RegisterConfiguration"
    elif helpers.has_method(&"RegisterConfigruation"):
        register_method = &"RegisterConfigruation"

    if register_method != &"":
        helpers.call(
            register_method,
            MOD_ID,
            "Medical Durability",
            MCM_CONFIG_DIR,
            "Configure max uses for medical items. Minimum value is 1.",
            {"config.ini": Callable(self, &"UpdateConfigProperties")}
        )

func _load_mcm_helpers() -> Object:
    for helper_path in MCM_HELPERS_CANDIDATES:
        if !ResourceLoader.exists(helper_path):
            continue

        var loaded: Variant = load(helper_path)
        if loaded != null and loaded is Object:
            return loaded as Object

    return null

func _build_mcm_config_schema(config: ConfigFile) -> void:
    var menu_pos := 10
    for item_key in _get_sorted_item_keys():
        var default_uses := int(DEFAULT_ITEM_USES[item_key])
        var config_key := _mcm_setting_key(item_key)
        var display_name := _format_item_name(item_key)

        config.set_value("Int", config_key, {
            "name": "Uses: " + display_name,
            "tooltip": "Maximum uses for " + display_name + ".",
            "default": default_uses,
            "value": default_uses,
            "minRange": 1,
            "maxRange": default_uses,
            "menu_pos": menu_pos
        })
        menu_pos += 1

func _apply_item_uses_from_config(config: ConfigFile) -> void:
    item_uses = DEFAULT_ITEM_USES.duplicate(true)

    for item_key in _get_sorted_item_keys():
        var default_uses := int(DEFAULT_ITEM_USES[item_key])
        var value := _read_mcm_int(config, _mcm_setting_key(item_key), default_uses, 1, default_uses)
        item_uses[item_key] = value

    _build_item_uses_lookup()

func _read_mcm_int(config: ConfigFile, key: String, fallback: int, min_value: int, max_value: int) -> int:
    var raw: Variant = config.get_value("Int", key, fallback)
    var value := fallback

    if raw is int:
        value = int(raw)
    elif raw is float:
        value = int(round(float(raw)))
    elif raw is Dictionary:
        var wrapped: Dictionary = raw
        var nested: Variant = wrapped.get("value", fallback)
        if nested is int:
            value = int(nested)
        elif nested is float:
            value = int(round(float(nested)))

    return int(clamp(value, min_value, max_value))

func _get_sorted_item_keys() -> PackedStringArray:
    var keys := PackedStringArray()
    for key in DEFAULT_ITEM_USES.keys():
        keys.append(str(key))
    keys.sort()
    return keys

func _format_item_name(item_key: String) -> String:
    return item_key.replace("_", " ")

func _mcm_setting_key(item_key: String) -> String:
    return "uses_" + _normalize_item_key(item_key)

func UpdateConfigProperties(config: ConfigFile) -> void:
    _apply_item_uses_from_config(config)
    call_deferred("_refresh_open_interface_items")

func _build_item_uses_lookup() -> void:
    item_uses_lookup.clear()
    for key in item_uses.keys():
        item_uses_lookup[_normalize_item_key(str(key))] = int(item_uses[key])

func _normalize_item_key(value: String) -> String:
    var key := value.strip_edges().to_lower()
    key = key.replace("_", "")
    key = key.replace(" ", "")
    key = key.replace("-", "")
    key = key.replace(".", "")
    return key

func _resolve_item_uses(itemData: ItemData) -> int:
    if itemData == null:
        return 1
    if item_uses_lookup.is_empty():
        _build_item_uses_lookup()

    var candidates := [
        str(itemData.file),
        str(itemData.name),
        str(itemData.inventory),
        str(itemData.rotated),
        str(itemData.display),
        str(itemData.equipment)
    ]

    for candidate in candidates:
        var normalized := _normalize_item_key(candidate)
        if normalized == "":
            continue
        if item_uses_lookup.has(normalized):
            return int(item_uses_lookup[normalized])

        # Save/load variants sometimes append prefixes or suffixes.
        for known in item_uses_lookup.keys():
            if normalized.begins_with(known) or known.begins_with(normalized):
                return int(item_uses_lookup[known])

    return 1

func _override_script(mod_script_path: String) -> void:
    var script := load(mod_script_path)
    if !script:
        push_error("[MedicalDurability] Failed to load: " + mod_script_path)
        return
    # script.reload()  # modloader: stripped (redundant + fires Cannot-reload error if instance exists)
    var parent_script: Script = script.get_base_script()
    if !parent_script:
        push_error("[MedicalDurability] No base script for: " + mod_script_path)
        return
    script.take_over_path(parent_script.resource_path)

func is_medical_item(itemData: ItemData) -> bool:
    if itemData == null:
        return false
    return _resolve_item_uses(itemData) > 1

func get_max_uses(itemData: ItemData) -> int:
    if itemData == null:
        return 1
    return _resolve_item_uses(itemData)

func _roll_initial_uses(max_uses: int) -> int:
    if max_uses <= 1:
        return 1

    var max_roll := max(1, int(ceil(float(max_uses) * initial_uses_max_ratio)))
    return _rng.randi_range(1, max_roll)

func prepare_slot_data(slotData: SlotData) -> void:
    if slotData == null or slotData.itemData == null:
        return

    var max_uses := get_max_uses(slotData.itemData)
    if max_uses <= 1:
        return

    # Use amount as the source of truth so it behaves like matches/ammo counters.
    slotData.itemData.showAmount = true

    if !slotData.has_meta(USES_INITIALIZED_META):
        slotData.set_meta(USES_INITIALIZED_META, true)
        var should_seed: bool = int(slotData.amount) <= 0

        # Fresh non-stackable items often start as amount == 1 in vanilla data.
        # Treat full-condition items as uninitialized and seed their real max uses.
        if slotData.amount == 1 and max_uses > 1:
            if int(slotData.condition) >= 100:
                should_seed = true
            else:
                # Preserve save data for partially used items that only expose condition.
                var inferred_uses := int(round((float(slotData.condition) / 100.0) * float(max_uses)))
                slotData.amount = max(1, inferred_uses)

        if should_seed:
            if randomize_initial_uses:
                slotData.amount = _roll_initial_uses(max_uses)
            else:
                slotData.amount = max_uses

    slotData.amount = int(clamp(slotData.amount, 0, max_uses))
    slotData.condition = int(round((float(slotData.amount) / float(max_uses)) * 100.0))

func get_uses_left(slotData: SlotData) -> int:
    if slotData == null or slotData.itemData == null:
        return 0
    var max_uses := get_max_uses(slotData.itemData)
    if max_uses <= 1:
        return 1
    prepare_slot_data(slotData)
    return int(clamp(slotData.amount, 0, max_uses))

func set_uses_left(slotData: SlotData, uses_left: int) -> void:
    if slotData == null or slotData.itemData == null:
        return
    var max_uses := get_max_uses(slotData.itemData)
    if max_uses <= 1:
        slotData.amount = 1
        slotData.condition = 100
        return
    uses_left = int(clamp(uses_left, 0, max_uses))
    slotData.amount = uses_left
    slotData.condition = int(round((float(uses_left) / float(max_uses)) * 100.0))

func consume_medical_use(slotData: SlotData) -> Dictionary:
    var result := {
        "handled": false,
        "remove_item": true,
        "spawn_used_items": true,
        "uses_left": 0,
        "max_uses": 1
    }
    if slotData == null or slotData.itemData == null:
        return result
    if !is_medical_item(slotData.itemData):
        return result

    prepare_slot_data(slotData)
    var max_uses := get_max_uses(slotData.itemData)
    result.max_uses = max_uses
    if max_uses <= 1:
        return result

    var uses_left := get_uses_left(slotData) - 1
    uses_left = max(uses_left, 0)
    set_uses_left(slotData, uses_left)

    result.handled = true
    result.uses_left = uses_left
    result.remove_item = uses_left <= 0
    result.spawn_used_items = uses_left <= 0
    return result

func should_show_condition(slotData: SlotData) -> bool:
    if slotData == null or slotData.itemData == null:
        return false
    if is_medical_item(slotData.itemData):
        return false
    if slotData.itemData.type == "Weapon" or slotData.itemData.type == "Armor" or slotData.itemData.type == "Helmet":
        return true
    if slotData.itemData.type == "Rig" and slotData.nested.size() != 0:
        for nested in slotData.nested:
            if nested.type == "Armor":
                return true
    return slotData.itemData.showCondition

func refresh_item_ui(interface_ref, item_ref) -> void:
    if item_ref == null:
        return
    if item_ref.has_method("UpdateDetails"):
        prepare_slot_data(item_ref.slotData)
        item_ref.UpdateDetails()
    if item_ref.has_method("UpdateAttachments"):
        item_ref.UpdateAttachments()
    if item_ref.has_method("UpdateSprite"):
        item_ref.UpdateSprite()
    if interface_ref and interface_ref.hoverItem == item_ref and interface_ref.tooltip:
        interface_ref.tooltip.Update(item_ref)

func _refresh_open_interface_items() -> void:
    if get_tree() == null or get_tree().root == null:
        return
    _refresh_node_recursive(get_tree().root)

func _refresh_node_recursive(node: Node) -> void:
    if node == null:
        return

    if node is Item:
        var item_node: Item = node
        if item_node.slotData != null:
            prepare_slot_data(item_node.slotData)
            item_node.UpdateDetails()

    for child in node.get_children():
        _refresh_node_recursive(child)
